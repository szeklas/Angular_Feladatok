import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { KezdolapComponent } from './kezdolap/kezdolap.component';
import { TablazatComponent } from './tablazat/tablazat.component';
import { Hiba404Component } from './hiba404/hiba404.component';
import { FormsModule } from '@angular/forms';
import { PrimEComponent } from './prim-e/prim-e.component';
import { TeglalapComponent } from './teglalap/teglalap.component';
import { HalmazallapotComponent } from './halmazallapot/halmazallapot.component';

@NgModule({
  declarations: [
    AppComponent,
    KezdolapComponent,
    TablazatComponent,
    Hiba404Component,
    PrimEComponent,
    TeglalapComponent,
    HalmazallapotComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
