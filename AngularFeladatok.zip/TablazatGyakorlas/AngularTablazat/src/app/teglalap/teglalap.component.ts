import { Component } from '@angular/core';

@Component({
  selector: 'app-teglalap',
  templateUrl: './teglalap.component.html',
  styleUrl: './teglalap.component.css'
})
export class TeglalapComponent {

  aOldal:number=1
  bOldal:number=1

}
