import { Component } from '@angular/core';

@Component({
  selector: 'app-halmazallapot',
  templateUrl: './halmazallapot.component.html',
  styleUrl: './halmazallapot.component.css'
})
export class HalmazallapotComponent {

  homerseklet:number=0
  visszajelzoUzenet!:string

  Halmazallapot(){
    if(this.homerseklet<0){
      this.visszajelzoUzenet="Szilárd (JÉG)"
    }
    else if(this.homerseklet>100){
      this.visszajelzoUzenet="Légnemű (GŐZ)"
    }
    else{
      this.visszajelzoUzenet="Folyékony (VÍZ)"
    }
  }

}
