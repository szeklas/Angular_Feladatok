import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KezdolapComponent } from './kezdolap/kezdolap.component';
import { TablazatComponent } from './tablazat/tablazat.component';
import { Hiba404Component } from './hiba404/hiba404.component';
import { PrimEComponent } from './prim-e/prim-e.component';
import { TeglalapComponent } from './teglalap/teglalap.component';
import { HalmazallapotComponent } from './halmazallapot/halmazallapot.component';

const routes: Routes = [
  {path:"kezdolap",component:KezdolapComponent},
  {path:"tablazat",component:TablazatComponent},
  {path:"primE",component:PrimEComponent},
  {path:"hiba404",component:Hiba404Component},
  {path:"teglalap",component:TeglalapComponent},
  {path:"halmazallapot",component:HalmazallapotComponent},
  {path:"",redirectTo:"/kezdolap",pathMatch:"full"},
  {path:"**",component:Hiba404Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
