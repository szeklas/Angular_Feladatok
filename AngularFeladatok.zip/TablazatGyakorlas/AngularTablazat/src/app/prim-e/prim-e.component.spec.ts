import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimEComponent } from './prim-e.component';

describe('PrimEComponent', () => {
  let component: PrimEComponent;
  let fixture: ComponentFixture<PrimEComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PrimEComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrimEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
