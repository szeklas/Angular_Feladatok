import { Component } from '@angular/core';

@Component({
  selector: 'app-prim-e',
  templateUrl: './prim-e.component.html',
  styleUrl: './prim-e.component.css'
})
export class PrimEComponent {

  vizsgalandoSzam!:number
  visszajelzoUzenet!:string

  szamok:string[]=[]

  PrimE(){
    let oszto=0
    for(let i=1;i<=this.vizsgalandoSzam;i++){
      if(this.vizsgalandoSzam%i==0){
        oszto++
      }
    }

    if(this.vizsgalandoSzam==null){
      alert("Hiba! Üresen hagyott mező.")
    }

    if(oszto==2){
      this.visszajelzoUzenet=`A ${this.vizsgalandoSzam} prím szám`
    }
    else{
      this.visszajelzoUzenet=`A ${this.vizsgalandoSzam} NEM prím szám`
    }

    this.szamok.push(this.visszajelzoUzenet)
  }

}
